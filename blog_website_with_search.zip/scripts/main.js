/*
 * Main JavaScript for the minimalist academic blog.
 *
 * Responsibilities:
 *  - Load category and post metadata from categories.json
 *  - Render navigation bar dynamically
 *  - Render recent posts, category pages and individual posts
 *  - Handle mobile menu toggling
 */

// Utility to fetch JSON files relative to the site root
async function fetchJSON(path) {
  const response = await fetch(path);
  if (!response.ok) {
    throw new Error(`Failed to fetch ${path}: ${response.statusText}`);
  }
  return await response.json();
}

// Utility to get query parameters
function getQueryParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
}

// Toggle navigation on mobile
function setupMenuToggle() {
  const toggle = document.getElementById('menu-toggle');
  const nav = document.getElementById('main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      nav.classList.toggle('open');
    });
  }
}

// Build navigation bar
async function buildNavigation(categories) {
  const nav = document.getElementById('main-nav');
  if (!nav) return;
  // Clear existing
  nav.innerHTML = '';
  // Add category links
  categories.forEach(cat => {
    const link = document.createElement('a');
    link.href = `category.html?category=${encodeURIComponent(cat.slug)}`;
    link.textContent = cat.name;
    nav.appendChild(link);
  });
  // Add About link
  const about = document.createElement('a');
  about.href = 'about.html';
  about.textContent = 'About';
  nav.appendChild(about);
}


// Build a compact search box in the header. It expands on click, hover, or keyboard focus.
function setupSearch(categories) {
  const header = document.querySelector('.site-header');
  const toggle = document.getElementById('menu-toggle');
  if (!header || document.getElementById('site-search')) return;

  const wrapper = document.createElement('div');
  wrapper.id = 'site-search';
  wrapper.className = 'search-wrapper';
  wrapper.innerHTML = `
    <button class="search-icon" type="button" aria-label="Open search">⌕</button>
    <input class="search-input" type="search" placeholder="Search posts…" aria-label="Search posts" />
    <div class="search-results" aria-live="polite"></div>
  `;

  header.insertBefore(wrapper, toggle);

  const icon = wrapper.querySelector('.search-icon');
  const input = wrapper.querySelector('.search-input');
  const results = wrapper.querySelector('.search-results');
  let indexPromise = null;

  icon.addEventListener('click', () => {
    wrapper.classList.add('open');
    input.focus();
  });

  input.addEventListener('focus', () => wrapper.classList.add('open'));

  document.addEventListener('click', (event) => {
    if (!wrapper.contains(event.target)) {
      wrapper.classList.remove('open');
      results.innerHTML = '';
    }
  });

  input.addEventListener('input', debounce(async () => {
    const query = input.value.trim().toLowerCase();
    if (query.length < 2) {
      results.innerHTML = '';
      return;
    }
    if (!indexPromise) indexPromise = buildSearchIndex(categories);
    const index = await indexPromise;
    const matches = index
      .map(item => ({ ...item, score: scoreSearchMatch(item, query) }))
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);

    renderSearchResults(matches, results, query);
  }, 180));
}

function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

async function buildSearchIndex(categories) {
  const posts = [];
  categories.forEach(category => {
    category.posts.forEach(post => {
      posts.push({ ...post, category: category.slug, categoryName: category.name });
    });
  });

  return await Promise.all(posts.map(async post => {
    let body = '';
    const basePath = `blogs/${post.category}/${post.slug}`;
    try {
      let response = await fetch(`${basePath}/content.md`);
      if (!response.ok) response = await fetch(`${basePath}/content.tex`);
      if (response.ok) body = await response.text();
    } catch (error) {
      console.warn('Search index could not load post content:', post.title, error);
    }
    return {
      ...post,
      searchTitle: (post.title || '').toLowerCase(),
      searchSummary: (post.summary || '').toLowerCase(),
      searchBody: stripMarkup(body).toLowerCase()
    };
  }));
}

function stripMarkup(text) {
  return text
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`[^`]*`/g, ' ')
    .replace(/\$[^$]*\$/g, ' ')
    .replace(/[#*_~>\[\]()`{}\\]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function scoreSearchMatch(item, query) {
  let score = 0;
  if (item.searchTitle.includes(query)) score += 6;
  if (item.searchSummary.includes(query)) score += 3;
  if (item.searchBody.includes(query)) score += 1;
  return score;
}

function renderSearchResults(matches, container, query) {
  if (!matches.length) {
    container.innerHTML = `<div class="search-empty">No results for “${escapeHTML(query)}”</div>`;
    return;
  }

  container.innerHTML = matches.map(post => `
    <a class="search-result" href="post.html?category=${encodeURIComponent(post.category)}&post=${encodeURIComponent(post.slug)}">
      <strong>${escapeHTML(post.title)}</strong>
      <span>${escapeHTML(post.categoryName)}${post.date ? ' • ' + new Date(post.date).toLocaleDateString() : ''}</span>
      <small>${escapeHTML(post.summary || '')}</small>
    </a>
  `).join('');
}

function escapeHTML(value) {
  return String(value).replace(/[&<>'"]/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[char]));
}

// Render recent posts on the homepage
function renderRecentPosts(categories) {
  const container = document.getElementById('recent-list');
  if (!container) return;
  // Flatten posts from all categories and sort by date descending
  const posts = [];
  categories.forEach(cat => {
    cat.posts.forEach(post => {
      posts.push({ ...post, category: cat.slug, categoryName: cat.name });
    });
  });
  posts.sort((a, b) => {
    const dateA = a.date ? new Date(a.date) : new Date(0);
    const dateB = b.date ? new Date(b.date) : new Date(0);
    return dateB - dateA;
  });
  // Show up to 5 recent posts
  const recent = posts.slice(0, 5);
  recent.forEach(post => {
    const card = document.createElement('div');
    card.className = 'post-card';
    const title = document.createElement('h2');
    const link = document.createElement('a');
    link.href = `post.html?category=${encodeURIComponent(post.category)}&post=${encodeURIComponent(post.slug)}`;
    link.textContent = post.title;
    title.appendChild(link);
    const meta = document.createElement('div');
    meta.className = 'meta';
    const dateStr = post.date ? new Date(post.date).toLocaleDateString() : '';
    meta.textContent = `${post.categoryName} • ${dateStr}`;
    const summary = document.createElement('p');
    summary.textContent = post.summary || '';
    card.appendChild(title);
    card.appendChild(meta);
    card.appendChild(summary);
    container.appendChild(card);
  });
}

// Render posts list for a category page
function renderCategoryPage(category) {
  const titleEl = document.getElementById('category-title');
  const listEl = document.getElementById('posts-list');
  if (titleEl) {
    titleEl.textContent = category.name;
  }
  if (listEl) {
    listEl.innerHTML = '';
    category.posts.forEach(post => {
      const card = document.createElement('div');
      card.className = 'post-card';
      const title = document.createElement('h2');
      const link = document.createElement('a');
      link.href = `post.html?category=${encodeURIComponent(category.slug)}&post=${encodeURIComponent(post.slug)}`;
      link.textContent = post.title;
      title.appendChild(link);
      const meta = document.createElement('div');
      meta.className = 'meta';
      const dateStr = post.date ? new Date(post.date).toLocaleDateString() : '';
      meta.textContent = dateStr;
      const summary = document.createElement('p');
      summary.textContent = post.summary || '';
      card.appendChild(title);
      card.appendChild(meta);
      card.appendChild(summary);
      listEl.appendChild(card);
    });
  }
}

// Render a single post page
async function renderPostPage(categorySlug, postSlug) {
  const article = document.getElementById('post-content');
  if (!article) return;
  // Build path
  const path = `blogs/${decodeURIComponent(categorySlug)}/${decodeURIComponent(postSlug)}`;
  // Fetch metadata
  let meta = {};
  try {
    meta = await fetchJSON(`${path}/meta.json`);
  } catch (err) {
    console.warn('No meta.json found for post:', err);
  }
  // Determine content file
  let contentFile = 'content.md';
  try {
    // Attempt to fetch markdown first; fallback to tex
    const mdResp = await fetch(`${path}/content.md`);
    if (!mdResp.ok) throw new Error('No MD');
    var contentText = await mdResp.text();
    contentFile = 'md';
  } catch (e) {
    const texResp = await fetch(`${path}/content.tex`);
    contentText = await texResp.text();
    contentFile = 'tex';
  }
  // Render title
  if (meta.title) {
    const heading = document.createElement('h1');
    heading.textContent = meta.title;
    article.appendChild(heading);
  }
  // Render date and tags
  if (meta.date || (meta.tags && meta.tags.length)) {
    const metaDiv = document.createElement('div');
    metaDiv.className = 'meta';
    const parts = [];
    if (meta.date) {
      parts.push(new Date(meta.date).toLocaleDateString());
    }
    if (meta.tags && meta.tags.length) {
      parts.push(meta.tags.join(', '));
    }
    metaDiv.textContent = parts.join(' • ');
    article.appendChild(metaDiv);
  }
  // Render content
  const contentDiv = document.createElement('div');
  if (contentFile === 'md') {
    contentDiv.innerHTML = marked.parse(contentText, { breaks: true });
  } else {
    // For LaTeX we escape HTML and wrap in pre/code
    const pre = document.createElement('pre');
    pre.textContent = contentText;
    contentDiv.appendChild(pre);
  }
  article.appendChild(contentDiv);
}

// Entry point
document.addEventListener('DOMContentLoaded', async () => {
  setupMenuToggle();
  // Load categories from JSON
  let data;
  try {
    data = await fetchJSON('categories.json');
  } catch (err) {
    console.error('Could not load categories.json', err);
    return;
  }
  const categories = data.categories || [];
  await buildNavigation(categories);
  setupSearch(categories);
  // Determine page by inspecting body classes or URL
  const path = window.location.pathname;
  const page = path.substring(path.lastIndexOf('/') + 1);
  if (page === 'index.html' || page === '' || page === '/') {
    renderRecentPosts(categories);
  } else if (page.startsWith('category')) {
    const slug = getQueryParam('category');
    if (!slug) return;
    const cat = categories.find(c => c.slug === decodeURIComponent(slug));
    if (cat) {
      renderCategoryPage(cat);
    } else {
      const titleEl = document.getElementById('category-title');
      if (titleEl) titleEl.textContent = 'Category Not Found';
    }
  } else if (page.startsWith('post')) {
    const catSlug = getQueryParam('category');
    const postSlug = getQueryParam('post');
    if (catSlug && postSlug) {
      await renderPostPage(catSlug, postSlug);
    }
  }
});